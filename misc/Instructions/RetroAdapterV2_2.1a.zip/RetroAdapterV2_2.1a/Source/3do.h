void Read3DO(report_t *reportBuffer);
uchar TDOReadByte();
