void ReadDB9(report_t *reportBuffer);
void ReadDB15(report_t *reportBuffer);

