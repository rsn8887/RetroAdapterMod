void ReadN64GC(report_t *reportBuffer);
