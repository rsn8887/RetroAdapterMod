void ReadAnalogue(report_t *reportBuffer, uchar id);
