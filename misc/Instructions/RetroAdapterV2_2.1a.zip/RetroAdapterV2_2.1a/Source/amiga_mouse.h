void ReadAmigaMouse(reportMouse_t *reportBufferMouse);
