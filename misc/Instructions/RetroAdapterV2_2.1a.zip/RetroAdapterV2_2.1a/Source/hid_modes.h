#define	HIDM_1P		0
#define	HIDM_2P		1
#define	HIDM_MOUSE	2
