void ReadAtariDriving(report_t *reportBuffer);
