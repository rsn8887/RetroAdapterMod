void ReadCD32(report_t *reportBuffer);
uchar CD32ReadBit(void);
