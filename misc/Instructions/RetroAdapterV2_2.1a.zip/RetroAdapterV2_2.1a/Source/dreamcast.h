#define	DC0		5
#define	DC1		4
#define	DCS		3

void ReadDreamcast(report_t *reportBuffer);
