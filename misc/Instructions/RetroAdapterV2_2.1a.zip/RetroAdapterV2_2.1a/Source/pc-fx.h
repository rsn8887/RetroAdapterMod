void ReadPCFX(report_t *reportBuffer);
uchar PCFXRead();
