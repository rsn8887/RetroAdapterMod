void ReadSegaPaddle(report_t *reportBuffer);
