void ReadTimers(report_t *reportBuffer);
