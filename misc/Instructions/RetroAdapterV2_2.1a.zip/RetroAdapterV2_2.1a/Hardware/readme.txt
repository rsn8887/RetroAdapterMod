                             Retro Adapter V2 1.0
                                       
                         Copyright 2009 Paul Qureshi
                                       
                           http://retro.world3.net

All code, schematics, PCB designs, firmware and other files included with this
archive are licensed under the GNU Public License V3, see license.txt for more
details.


1. Schematics and PCB
=====================

The schematics and PCB are provided in Cadsoft Eagle format. Eagle can be
downloaded for free from the Cadsoft web site, and can be used to export
the data in a variety for formats.

The PCB is quite small so as to fit inside a DB9-DB25 adapter box. See the
web site for photos and to buy PCBs.



2. History
==========

1.0		- First release, no known issues.
